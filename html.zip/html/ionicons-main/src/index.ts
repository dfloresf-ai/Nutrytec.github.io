export { setAssetPath } from '@stencil/core';

export { addIcons } from './components/icon/utils';
export type { Components, JSX } from './components';
