# Change Log

Please see https://github.com/ionic-team/ionicons/releases